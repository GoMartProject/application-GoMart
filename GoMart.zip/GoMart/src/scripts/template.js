// start loader halaman
export function generateLoaderAbsoluteTemplate() {
  return `
    <div class="loader loader-absolute"></div>
  `;
}
// end loader halaman

// start navbar
export function generateUnauthenticatedNavigationListTemplate() {
  return `
    <li><a href="#/login">Login</a></li>
    <li><a href="#/register">Register</a></li>
  `;
}

export function generateAuthenticatedNavigationListTemplate() {
  return `
    <li><a id="logout-button" class="logout-button" href="#/logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
  `;
}

export function generateMainNavigationListTemplate() {
  return `
    <li><a id="masterBarang-button" class="masterBarang-button" href="#/masterBarang">Data Master Barang</a></li>
    <li><a id="masterPelanggan-button" class="masterPelanggan-button" href="#/masterPelanggan">Data Master Pelanggan</a></li>
    <li><a id="transaksiPenjualan-button" class="transaksiPenjualan-button" href="#/transaksiPenjualan">Transaksi Penjualan</a></li>
    <li><a id="laporanPenjualan-button" class="laporanPenjualan-button" href="#/laporan">Laporan Penjualan</a></li>
  `;
}
// end navbar
