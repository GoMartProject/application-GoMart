// export const access_token_key = 'accessToken';
export const base_url = 'http://localhost:5000';

export const access_token_key = 'accessToken';
