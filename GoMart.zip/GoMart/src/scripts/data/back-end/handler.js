// handler.js
const { users, barangs, pelanggans, transaksis } = require('./GoMart');
const { nanoid } = require('nanoid');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'rahasiaSuperAman123';

const generateNextBarangId = () => {
  if (barangs.length === 0) {
    return 'BRG001';
  }

  const lastNumber = barangs
    .map((barang) => {
      const match = barang.id.match(/^BRG(\d+)$/);
      return match ? parseInt(match[1], 10) : 0;
    })
    .sort((a, b) => b - a)[0];

  const nextNumber = (lastNumber || 0) + 1;
  return `BRG${nextNumber.toString().padStart(3, '0')}`;
};

const generateNextPelangganId = () => {
  if (pelanggans.length === 0) {
    return 'PLG001';
  }

  const lastNumber = pelanggans
    .map((pelanggan) => {
      const match = pelanggan.id.match(/^PLG(\d+)$/);
      return match ? parseInt(match[1], 10) : 0;
    })
    .sort((a, b) => b - a)[0];

  const nextNumber = (lastNumber || 0) + 1;
  return `PLG${nextNumber.toString().padStart(3, '0')}`;
};

let allTransaksis = [];

function generateNextTransaksiId() {
  const validTransaksis = Array.isArray(transaksis) ? transaksis : [];

  const latestIdNumber =
    validTransaksis
      .map((transaksi) => {
        const id = transaksi?.idPenjualan;
        if (typeof id === 'string') {
          const match = id.match(/TRX(\d+)/);
          return match ? parseInt(match[1]) : 0;
        }
        return 0;
      })
      .sort((a, b) => b - a)[0] || 0;

  const nextIdNumber = latestIdNumber + 1;
  return `TRX${String(nextIdNumber).padStart(3, '0')}`;
}

// REGISTER
const goRegister = async (request, h) => {
  const { name, email, password } = request.payload;

  const userExist = users.find((u) => u.email === email);
  if (userExist) {
    return h
      .response({
        error: true,
        message: 'Email sudah terdaftar',
      })
      .code(400);
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const id = `user-${nanoid(16)}`;

  const newUser = {
    id,
    name,
    email,
    password: hashedPassword,
  };

  users.push(newUser);

  return h
    .response({
      error: false,
      message: 'success',
      loginResult: {
        userId: newUser.id,
        name: newUser.name,
      },
    })
    .code(201);
};

// LOGIN
const goLogin = async (request, h) => {
  const { email, password } = request.payload;

  const user = users.find((u) => u.email === email);
  if (!user) {
    return h
      .response({
        error: true,
        message: 'Email tidak ditemukan',
      })
      .code(404);
  }

  const passwordMatch = await bcrypt.compare(password, user.password);
  if (!passwordMatch) {
    return h
      .response({
        error: true,
        message: 'Password salah',
      })
      .code(401);
  }

  const token = jwt.sign({ userId: user.id, name: user.name }, SECRET_KEY, { expiresIn: '2h' });

  return h
    .response({
      error: false,
      message: 'success',
      loginResult: {
        userId: user.id,
        name: user.name,
        token,
      },
    })
    .code(200);
};

const getUserProfile = async (request, h) => {
  const authHeader = request.headers.authorization;

  if (!authHeader) {
    return h
      .response({
        error: true,
        message: 'Token tidak ditemukan',
      })
      .code(401);
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, SECRET_KEY);

    const user = users.find((u) => u.id === decoded.userId);
    if (!user) {
      throw new Error('User tidak ditemukan');
    }

    return {
      error: false,
      message: 'success',
      profile: {
        userId: user.id,
        name: user.name,
        email: user.email,
      },
    };
  } catch (err) {
    return h
      .response({
        error: true,
        message: 'Token tidak valid',
      })
      .code(403);
  }
};

// MASTER BARANG
const addMasterBarang = async (request, h) => {
  const { namaBarang, kuantitas, harga, satuan, kategori } = request.payload;

  if (!namaBarang || !kuantitas || !harga || !satuan || !kategori) {
    const response = h.response({
      status: 'fail',
      message: 'Gagal menambahkan data barang. Mohon isi semua field data barang.',
    });
    response.code(400);
    return response;
  }

  const barangExist = barangs.find((b) => b.namaBarang.toLowerCase() === namaBarang.toLowerCase());
  if (barangExist) {
    return h
      .response({
        status: 'fail',
        message: 'Gagal menambahkan data barang. Nama barang sudah ada.',
      })
      .code(400);
  }

  const id = generateNextBarangId();

  const newBarang = {
    id,
    namaBarang,
    kuantitas,
    harga,
    satuan,
    kategori,
  };

  barangs.push(newBarang);

  const isSuccess = barangs.filter((mart) => mart.id === id).length > 0;
  if (isSuccess) {
    const response = h.response({
      status: 'success',
      message: 'Barang berhasil ditambahkan',
      data: {
        goMartId: id,
        namaBarang: namaBarang,
      },
    });

    response.code(201);
    return response;
  }

  const response = h.response({
    status: 'fail',
    message: 'Data barang gagal ditambahkan',
  });
  response.code(500);
  return response;
};

const getAllBarang = (request, h) => {
  return h
    .response({
      status: 'success',
      data: barangs,
    })
    .code(200);
};

const deleteBarang = (request, h) => {
  const { id } = request.params;
  const index = barangs.findIndex((b) => b.id === id);

  if (index !== -1) {
    barangs.splice(index, 1);
    return h
      .response({
        status: 'success',
        message: 'Barang berhasil dihapus',
      })
      .code(200);
  }

  return h
    .response({
      status: 'fail',
      message: 'Barang tidak ditemukan',
    })
    .code(404);
};

const updateBarang = async (request, h) => {
  const { id } = request.params;
  const { namaBarang, kuantitas, harga, satuan, kategori } = request.payload;

  if (!id) {
    return h
      .response({
        status: 'fail',
        message: 'Gagal memperbarui barang. ID barang tidak ditemukan.',
      })
      .code(400);
  }

  const index = barangs.findIndex((b) => b.id === id);
  if (index === -1) {
    return h
      .response({
        status: 'fail',
        message: 'Barang tidak ditemukan',
      })
      .code(404);
  }

  const existingBarang = barangs[index];
  if (existingBarang.namaBarang.toLowerCase() !== namaBarang.toLowerCase()) {
    const nameDuplicate = barangs.some(
      (b) => b.namaBarang.toLowerCase() === namaBarang.toLowerCase() && b.id !== id,
    );
    if (nameDuplicate) {
      return h
        .response({
          status: 'fail',
          message: 'Gagal memperbarui barang. Nama barang sudah ada.',
        })
        .code(400);
    }
  }

  barangs[index] = { id, namaBarang, kuantitas, harga, satuan, kategori };

  return h
    .response({
      status: 'success',
      message: 'Barang berhasil diperbarui',
    })
    .code(200);
};

const addMasterPelanggan = (request, h) => {
  const { namaPelanggan, alamat, noTelp } = request.payload;

  if (!namaPelanggan || !alamat || !noTelp) {
    const response = h.response({
      status: 'fail',
      message: 'Gagal menambahkan data pelanggan. Mohon isi semua field data pelanggan!',
    });
    response.code(400);
    return response;
  }

  const pelangganExist = pelanggans.find(
    (p) => p.namaPelanggan.toLowerCase() === namaPelanggan.toLowerCase(),
  );
  if (pelangganExist) {
    return h
      .response({
        status: 'fail',
        message: 'Gagal menambahkan data pelanggan. Nama pelanggan sudah ada.',
      })
      .code(400);
  }

  const id = generateNextPelangganId();

  const newPelanggan = {
    id,
    namaPelanggan,
    alamat,
    noTelp,
  };

  pelanggans.push(newPelanggan);

  const isSuccess = pelanggans.filter((mart) => mart.id === id).length > 0;
  if (isSuccess) {
    const response = h.response({
      status: 'success',
      message: 'Pelanggan berhasil ditambahkan',
      data: {
        goMartId: id,
        namaPelanggan: namaPelanggan,
      },
    });
    response.code(201);
    return response;
  }

  const response = h.response({
    status: 'fail',
    message: 'Data pelanggan gagal ditambahkan',
  });
  response.code(500);
  return response;
};

const getAllPelanggan = (request, h) => {
  return h
    .response({
      status: 'success',
      data: pelanggans,
    })
    .code(200);
};

const deletePelanggan = (request, h) => {
  const { id } = request.params;
  const index = pelanggans.findIndex((i) => i.id === id);

  if (index !== -1) {
    pelanggans.splice(index, 1);
    return h
      .response({
        status: 'success',
        message: 'Pelanggan berhasil dihapus',
      })
      .code(200);
  }

  return h
    .response({
      status: 'fail',
      message: 'Pelanggan tidak ditemukan',
    })
    .code(404);
};

const updatePelanggan = async (request, h) => {
  const { id } = request.params;
  const { namaPelanggan, alamat, noTelp } = request.payload;

  if (!id) {
    return h
      .response({
        status: 'fail',
        message: 'Gagal memperbarui pelanggan. ID pelanggan tidak ditemukan.',
      })
      .code(400);
  }

  const index = pelanggans.findIndex((i) => i.id === id);
  if (index === -1) {
    return h
      .response({
        status: 'fail',
        message: 'Pelanggan tidak ditemukan',
      })
      .code(404);
  }

  const existingPelanggan = pelanggans[index];
  if (existingPelanggan.namaPelanggan.toLowerCase() !== namaPelanggan.toLowerCase()) {
    const nameDuplicate = pelanggans.some(
      (p) => p.namaPelanggan.toLowerCase() === namaPelanggan.toLowerCase() && p.id !== id,
    );
    if (nameDuplicate) {
      return h
        .response({
          status: 'fail',
          message: 'Gagal memperbarui pelanggan. Nama pelanggan sudah ada.',
        })
        .code(400);
    }
  }

  pelanggans[index] = { id, namaPelanggan, alamat, noTelp };

  return h
    .response({
      status: 'success',
      message: 'Pelanggan berhasil diperbarui',
    })
    .code(200);
};

const updateBarangStock = (idBarang, quantityChange) => {
  const index = barangs.findIndex((b) => b.id === idBarang);
  if (index !== -1) {
    barangs[index].kuantitas += quantityChange;
    return true;
  }
  return false;
};

const addTransaksi = (request, h) => {
  const { idPelanggan, tanggalPenjualan, items, jumlahUangPelanggan } = request.payload;
  const newId = generateNextTransaksiId(allTransaksis);

  if (
    !idPelanggan ||
    !tanggalPenjualan ||
    !items ||
    items.length === 0 ||
    typeof jumlahUangPelanggan !== 'number' ||
    isNaN(jumlahUangPelanggan) ||
    jumlahUangPelanggan === null
  ) {
    return h
      .response({
        status: 'fail',
        message:
          'Gagal menambahkan transaksi. Mohon lengkapi semua data transaksi (pelanggan, tanggal, item, dan jumlah uang).',
      })
      .code(400);
  }

  const pelanggan = pelanggans.find((p) => p.id === idPelanggan);
  if (!pelanggan) {
    return h
      .response({
        status: 'fail',
        message: 'Pelanggan tidak ditemukan.',
      })
      .code(404);
  }

  let totalTransaksi = 0;
  const detailItems = [];
  const stockUpdates = [];

  for (const item of items) {
    const { idBarang, kuantitas } = item;
    const barang = barangs.find((b) => b.id === idBarang);

    if (!barang) {
      return h
        .response({
          status: 'fail',
          message: `Barang dengan ID ${idBarang} tidak ditemukan.`,
        })
        .code(404);
    }

    if (kuantitas <= 0) {
      return h
        .response({
          status: 'fail',
          message: `Kuantitas barang ${barang.namaBarang} harus lebih dari 0.`,
        })
        .code(400);
    }

    if (barang.kuantitas < kuantitas) {
      return h
        .response({
          status: 'fail',
          message: `Stok barang ${barang.namaBarang} tidak mencukupi. Tersedia: ${barang.kuantitas}, Diminta: ${kuantitas}.`,
        })
        .code(400);
    }

    const subtotal = kuantitas * barang.harga;
    totalTransaksi += subtotal;

    detailItems.push({
      idBarang: barang.id,
      namaBarang: barang.namaBarang,
      kuantitas: kuantitas,
      harga: barang.harga,
      subtotal: subtotal,
    });

    stockUpdates.push({ idBarang: barang.id, change: -kuantitas });
  }

  if (jumlahUangPelanggan < totalTransaksi) {
    return h
      .response({
        status: 'fail',
        message: `Jumlah uang pelanggan kurang. Total belanja adalah ${totalTransaksi.toLocaleString('id-ID')}.`,
      })
      .code(400);
  }

  const kembalian = jumlahUangPelanggan - totalTransaksi;
  const idPenjualan = generateNextTransaksiId();

  const tanggalTransaksiISO = new Date(tanggalPenjualan).toISOString();

  const newTransaksi = {
    idPenjualan,
    tanggalPenjualan: tanggalTransaksiISO,
    idPelanggan: pelanggan.id,
    namaPelanggan: pelanggan.namaPelanggan,
    items: detailItems,
    total: totalTransaksi,
    tanggal: new Date().toISOString(),
    jumlahUangPelanggan,
    kembalian,
  };

  transaksis.push(newTransaksi);

  stockUpdates.forEach((update) => {
    updateBarangStock(update.idBarang, update.change);
  });

  const isSuccess = transaksis.filter((mart) => mart.idPenjualan === idPenjualan).length > 0;
  if (isSuccess) {
    const response = h.response({
      status: 'success',
      message: 'Transaksi berhasil ditambahkan',
      data: {
        goMartId: idPenjualan,
        total: totalTransaksi,
        kembalian: kembalian,
      },
    });

    response.code(201);
    return response;
  }

  const response = h.response({
    status: 'fail',
    message: 'Data transaksi gagal ditambahkan',
  });
  response.code(500);
  return response;
};

const getAllTransaksi = (request, h) => {
  return h
    .response({
      status: 'success',
      data: transaksis,
    })
    .code(200);
};

const getTransaksiById = (request, h) => {
  const { id } = request.params;
  const transaksi = transaksis.find((t) => t.idPenjualan === id);

  if (transaksi) {
    return h
      .response({
        status: 'success',
        data: transaksi,
      })
      .code(200);
  }

  return h
    .response({
      status: 'fail',
      message: 'Transaksi tidak ditemukan',
    })
    .code(404);
};

const updateTransaksi = (request, h) => {
  const { id } = request.params;
  const { idPelanggan, items, jumlahUangPelanggan } = request.payload;

  const index = transaksis.findIndex((t) => t.idPenjualan === id);
  if (index === -1) {
    return h
      .response({
        status: 'fail',
        message: 'Transaksi tidak ditemukan',
      })
      .code(404);
  }

  const pelanggan = pelanggans.find((p) => p.id === idPelanggan);
  if (!pelanggan) {
    return h
      .response({
        status: 'fail',
        message: 'Pelanggan tidak ditemukan.',
      })
      .code(404);
  }

  let totalTransaksi = 0;
  const detailItems = [];

  for (const item of items) {
    const { idBarang, kuantitas } = item;
    const barang = barangs.find((b) => b.id === idBarang);

    if (!barang) {
      return h
        .response({
          status: 'fail',
          message: `Barang dengan ID ${idBarang} tidak ditemukan.`,
        })
        .code(404);
    }
    if (kuantitas <= 0) {
      return h
        .response({
          status: 'fail',
          message: `Kuantitas barang ${barang.namaBarang} harus lebih dari 0.`,
        })
        .code(400);
    }

    const subtotal = kuantitas * barang.harga;
    totalTransaksi += subtotal;

    detailItems.push({
      idBarang: barang.id,
      namaBarang: barang.namaBarang,
      kuantitas: kuantitas,
      harga: barang.harga,
      subtotal: subtotal,
    });
  }

  if (jumlahUangPelanggan < totalTransaksi) {
    return h
      .response({
        status: 'fail',
        message: `Jumlah uang pelanggan kurang. Total belanja adalah ${totalTransaksi}.`,
      })
      .code(400);
  }

  const kembalian = jumlahUangPelanggan - totalTransaksi;

  transaksis[index] = {
    ...transaksis[index],
    idPelanggan: pelanggan.id,
    namaPelanggan: pelanggan.namaPelanggan,
    items: detailItems,
    total: totalTransaksi,
    jumlahUangPelanggan,
    kembalian,
  };

  return h
    .response({
      status: 'success',
      message: 'Transaksi berhasil diperbarui',
    })
    .code(200);
};

const deleteTransaksi = (request, h) => {
  const { id } = request.params;
  const index = transaksis.findIndex((t) => t.idPenjualan === id);

  if (index !== -1) {
    const deletedTransaksi = transaksis[index];
    // Kembalikan stok barang yang dihapus
    deletedTransaksi.items.forEach((item) => {
      updateBarangStock(item.idBarang, item.kuantitas);
    });

    transaksis.splice(index, 1);
    return h
      .response({
        status: 'success',
        message: 'Transaksi berhasil dihapus dan stok barang dikembalikan.',
      })
      .code(200);
  }

  return h
    .response({
      status: 'fail',
      message: 'Transaksi tidak ditemukan',
    })
    .code(404);
};

const getLaporanPenjualan = (request, h) => {
  const { startDate, endDate } = request.query;

  if (!startDate || !endDate) {
    return h
      .response({
        status: 'fail',
        message:
          'Mohon masukkan tanggal mulai (startDate) dan tanggal akhir (endDate) untuk laporan.',
      })
      .code(400);
  }

  const start = new Date(startDate);
  const end = new Date(endDate);
  end.setHours(23, 59, 59, 999);

  if (isNaN(start.getTime()) || isNaN(end.getTime())) {
    return h
      .response({
        status: 'fail',
        message: 'Format tanggal tidak valid. Gunakan format YYYY-MM-DD.',
      })
      .code(400);
  }

  const filteredTransaksis = transaksis
    .filter((t) => {
      const transaksiDate = new Date(t.tanggalPenjualan);
      return transaksiDate >= start && transaksiDate <= end;
    })
    .sort((a, b) => new Date(a.tanggalPenjualan) - new Date(b.tanggalPenjualan));

  let totalPenjualanPeriode = 0;
  const laporanDetail = filteredTransaksis.map((t) => {
    totalPenjualanPeriode += t.total;
    return {
      idPenjualan: t.idPenjualan,
      tanggalPenjualan: t.tanggalPenjualan,
      namaPelanggan: t.namaPelanggan,
      items: t.items.map((item) => ({
        idBarang: item.idBarang,
        namaBarang: item.namaBarang,
        kuantitas: item.kuantitas,
        harga: item.harga,
        subtotal: item.subtotal,
      })),
      total: t.total,
      jumlahUangPelanggan: t.jumlahUangPelanggan,
      kembalian: t.kembalian,
    };
  });

  return h
    .response({
      status: 'success',
      message: 'Laporan penjualan berhasil diambil',
      data: {
        periode: `${new Date(startDate).toLocaleDateString('id-ID')} - ${new Date(endDate).toLocaleDateString('id-ID')}`,
        totalPenjualan: totalPenjualanPeriode,
        transaksi: laporanDetail,
      },
    })
    .code(200);
};

module.exports = {
  goRegister,
  goLogin,
  getUserProfile,
  addMasterBarang,
  getAllBarang,
  deleteBarang,
  updateBarang,
  addMasterPelanggan,
  getAllPelanggan,
  deletePelanggan,
  updatePelanggan,
  addTransaksi,
  getAllTransaksi,
  getTransaksiById,
  updateTransaksi,
  deleteTransaksi,
  getLaporanPenjualan,
};
