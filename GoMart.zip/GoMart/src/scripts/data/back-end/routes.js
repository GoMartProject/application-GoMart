const {
  goRegister,
  goLogin,
  getUserProfile,
  addMasterBarang,
  getAllBarang,
  deleteBarang,
  updateBarang,
  addMasterPelanggan,
  getAllPelanggan,
  deletePelanggan,
  updatePelanggan,
  addTransaksi,
  getAllTransaksi,
  getTransaksiById,
  updateTransaksi,
  deleteTransaksi,
  getLaporanPenjualan,
} = require('./handler');

const routes = [
  // menambahkan user
  {
    method: 'POST',
    path: '/register',
    handler: goRegister,
  },

  // login user
  {
    method: 'POST',
    path: '/login',
    handler: goLogin,
  },

  // Master Barang
  { method: 'POST', path: '/masterbarang', handler: addMasterBarang },
  { method: 'GET', path: '/masterbarang', handler: getAllBarang },
  { method: 'DELETE', path: '/masterbarang/{id}', handler: deleteBarang },
  { method: 'PUT', path: '/masterbarang/{id}', handler: updateBarang },

  // Master Pelanggan
  { method: 'POST', path: '/masterpelanggan', handler: addMasterPelanggan },
  { method: 'GET', path: '/masterpelanggan', handler: getAllPelanggan },
  { method: 'DELETE', path: '/masterpelanggan/{id}', handler: deletePelanggan },
  { method: 'PUT', path: '/masterpelanggan/{id}', handler: updatePelanggan },

  // --- Rute Transaksi ---
  { method: 'POST', path: '/transaksi', handler: addTransaksi },
  { method: 'GET', path: '/transaksi', handler: getAllTransaksi },
  { method: 'GET', path: '/transaksi/{id}', handler: getTransaksiById },
  { method: 'PUT', path: '/transaksi/{id}', handler: updateTransaksi },
  { method: 'DELETE', path: '/transaksi/{id}', handler: deleteTransaksi },

  // --- Rute Laporan ---
  { method: 'GET', path: '/laporan/penjualan', handler: getLaporanPenjualan },
];

module.exports = routes;
