npm install @hapi/hapi
npm install nodemon --save-dev
npm install nanoid@3
npm install jsonwebtoken bcrypt