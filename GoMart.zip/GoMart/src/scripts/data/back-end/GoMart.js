const users = [];
const barangs = [];
const pelanggans = [];
const transaksis = [];
module.exports = { users, barangs, pelanggans, transaksis };
