import { base_url } from '../config';
import { access_token_key } from '../config';

const ENDPOINTS = {
  // AUTH
  REGISTER: `${base_url}/register`,
  LOGIN: `${base_url}/login`,

  BARANG: `${base_url}/masterbarang`,
  PELANGGAN: `${base_url}/masterpelanggan`,
  TRANSAKSI: `${base_url}/transaksi`,
  LAPORAN_PENJUALAN: `${base_url}/laporan/penjualan`,
};

export async function getRegistered({ name, email, password }) {
  const data = JSON.stringify({ name, email, password });

  const fetchResponse = await fetch(ENDPOINTS.REGISTER, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: data,
  });

  const json = await fetchResponse.json();

  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function getLogin({ email, password }) {
  const data = JSON.stringify({ email, password });

  const fetchResponse = await fetch(ENDPOINTS.LOGIN, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'Authorization': `Bearer ${access_token_key}`,
    },
    body: data,
  });

  const json = await fetchResponse.json();

  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function storeNewBarang({ namaBarang, kuantitas, harga, satuan, kategori }) {
  const data = JSON.stringify({ namaBarang, kuantitas, harga, satuan, kategori });

  const fetchResponse = await fetch(ENDPOINTS.BARANG, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: data,
  });

  const json = await fetchResponse.json();

  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function getAllBarang() {
  const fetchResponse = await fetch(ENDPOINTS.BARANG);
  const json = await fetchResponse.json();
  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function deleteBarangById(id) {
  const fetchResponse = await fetch(`${ENDPOINTS.BARANG}/${id}`, {
    method: 'DELETE',
  });

  const json = await fetchResponse.json();
  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function updateBarang(barang) {
  const data = JSON.stringify(barang);
  const { id } = barang;

  const fetchResponse = await fetch(`${ENDPOINTS.BARANG}/${id}`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: data,
  });

  const json = await fetchResponse.json();

  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function storeNewPelanggan({ namaPelanggan, alamat, noTelp }) {
  const data = JSON.stringify({ namaPelanggan, alamat, noTelp });

  const fetchResponse = await fetch(ENDPOINTS.PELANGGAN, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: data,
  });

  const json = await fetchResponse.json();

  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function getAllPelanggan() {
  const fetchResponse = await fetch(ENDPOINTS.PELANGGAN);
  const json = await fetchResponse.json();
  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function deletePelangganById(id) {
  const fetchResponse = await fetch(`${ENDPOINTS.PELANGGAN}/${id}`, {
    method: 'DELETE',
  });

  const json = await fetchResponse.json();
  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function updatePelanggan(pelanggan) {
  const data = JSON.stringify(pelanggan);
  const { id } = pelanggan;

  const fetchResponse = await fetch(`${ENDPOINTS.PELANGGAN}/${id}`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: data,
  });

  const json = await fetchResponse.json();

  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function storeNewTransaksi({
  idPelanggan,
  tanggalPenjualan,
  items,
  jumlahUangPelanggan,
}) {
  const data = JSON.stringify({ idPelanggan, tanggalPenjualan, items, jumlahUangPelanggan });

  const fetchResponse = await fetch(ENDPOINTS.TRANSAKSI, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: data,
  });

  const json = await fetchResponse.json();
  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function getAllTransaksiAPI() {
  const fetchResponse = await fetch(ENDPOINTS.TRANSAKSI);
  const json = await fetchResponse.json();
  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function getTransaksiByIdAPI(id) {
  const fetchResponse = await fetch(`${ENDPOINTS.TRANSAKSI}/${id}`);
  const json = await fetchResponse.json();
  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function updateTransaksiAPI(id, { idPelanggan, items, jumlahUangPelanggan }) {
  const data = JSON.stringify({ idPelanggan, items, jumlahUangPelanggan });

  const fetchResponse = await fetch(`${ENDPOINTS.TRANSAKSI}/${id}`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: data,
  });

  const json = await fetchResponse.json();
  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function deleteTransaksiAPI(id) {
  const fetchResponse = await fetch(`${ENDPOINTS.TRANSAKSI}/${id}`, {
    method: 'DELETE',
  });

  const json = await fetchResponse.json();
  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function getLaporanPenjualanAPI({ startDate, endDate }) {
  const fetchResponse = await fetch(
    `${ENDPOINTS.LAPORAN_PENJUALAN}?startDate=${startDate}&endDate=${endDate}`,
  );
  const json = await fetchResponse.json();
  return {
    ...json,
    ok: fetchResponse.ok,
  };
}
