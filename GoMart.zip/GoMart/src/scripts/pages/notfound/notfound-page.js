export default class notFound {
  async render() {
    return `
            <h1>Halaman tidak ditemukan. Silahkan refresh!</h1>
        `;
  }

  async afterRender() {}
}
