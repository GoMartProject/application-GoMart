export default class HomePage {
  async render() {
    return `
            <section class="information">
            
                <h1>Halo, ini adalah aplikasi GoMart</h1>
                <h3>Aplikasi ini digunakan untuk bisnis penjualan, berikut developernya:</h3>
                <p>FC172D5Y1843 - Karan</p>
                <p>FC172D5X1845 - Sheany Multa Kandi</p>
                <p>MC833D5Y0302 - Muhammad Septiyanto</p>
                <p>MC012D5Y2159- Jibril Nikki Ghiffari</p>
                <p>FC288D5Y1014 - Fabio Eltra Mahardhika</p>
            </section>
        `;
  }

  async afterRender() {}
}
