// src/pages/transaksi/transaksi-page.js
import * as GoMartAPI from '../../data/api';
import transaksiPresenter from './transaksi-presenter';

export default class TransaksiPage {
  #presenter;
  #selectedItems = [];
  #pelangganList = [];
  #barangList = [];
  #editMode = false;
  #originalTransaksiItems = [];

  async render() {
    return `
            <div class="container-transaksi">
                <h2>Pencatatan Penjualan</h2>

                <form id="transaksiForm" class="transaksiForm">
                    <div class="header-section">
                        <div class="form-control">
                            <label for="idPenjualan">ID Penjualan</label>
                            <input type="text" id="idPenjualan" placeholder="Otomatis" disabled>
                        </div>
                        <div class="form-control">
                            <label for="tanggalPenjualan">Tanggal Penjualan</label>
                            <input type="date" id="tanggalPenjualan" required>
                        </div>
                        <div class="form-control">
                            <label for="idPelanggan">Pelanggan</label>
                            <select id="idPelanggan" required>
                                <option value="">-- Pilih Pelanggan --</option>
                            </select>
                        </div>
                        <div class="form-control">
                            <label for="namaPelanggan">Nama Pelanggan</label>
                            <input type="text" id="namaPelanggan" disabled>
                        </div>
                    </div>

                    <h3>Detail Barang</h3>
                    <div class="detail-section">
                        <div class="form-control">
                            <label for="idBarang">Barang</label>
                            <select id="idBarang">
                                <option value="">-- Pilih Barang --</option>
                            </select>
                        </div>
                        <div class="form-control">
                            <label for="namaBarangDetail">Nama Barang</label>
                            <input type="text" id="namaBarangDetail" disabled>
                        </div>
                        <div class="form-control">
                            <label for="stokBarangDetail">Stok Tersedia</label>
                            <input type="number" id="stokBarangDetail" disabled>
                        </div>
                        <div class="form-control">
                            <label for="hargaBarangDetail">Harga Satuan</label>
                            <input type="number" id="hargaBarangDetail" disabled>
                        </div>
                        <div class="form-control">
                            <label for="kuantitasDetail">Kuantitas</label>
                            <input type="number" id="kuantitasDetail" min="1" value="">
                        </div>
                        <button type="button" id="addItemBtn" class="btn-add-item">Tambah Item</button>
                    </div>

                    <div class="table-wrapper detail-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Kuantitas</th>
                                    <th>Harga</th>
                                    <th>Subtotal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="transaksiDetailTableBody">
                            </tbody>
                        </table>
                    </div>

                    <div class="summary-section">
                        <div class="form-control">
                            <label for="totalBelanja">Total Belanja</label>
                            <input type="text" id="totalBelanja" value="0" disabled>
                        </div>
                        <div class="form-control">
                            <label for="jumlahUangPelanggan">Jumlah Uang Pelanggan</label>
                            <input type="number" id="jumlahUangPelanggan" min="0" required>
                        </div>
                        <div class="form-control">
                            <label for="kembalian">Kembalian</label>
                            <input type="text" id="kembalian" value="0" disabled>
                        </div>
                    </div>
                    
                    <div class="form-buttons">
                        <button type="submit" class="submit-transaksi btn">Simpan Transaksi</button>
                        <button type="button" id="resetFormBtn" class="btn-reset">Reset</button>
                        <button type="button" id="cancelEditTransaksiBtn" class="btn-cancel-edit" style="display: none;">Batal Edit</button>
                    </div>
                </form>

                <hr>

                <h2>Daftar Transaksi</h2>
                <div class="transaksi-search">
                    <input
                        type="text"
                        id="searchTransaksiInput"
                        placeholder="Cari transaksi berdasarkan ID atau nama pelanggan..."
                    />
                </div>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>ID Penjualan</th>
                                <th>Tanggal</th>
                                <th>Pelanggan</th>
                                <th>Total</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="transaksiTableBody">
                        </tbody>
                    </table>
                </div>
            </div>

            <div id="transaksiDetailModal" class="modal">
                <div class="modal-content">
                    <span class="close-button">&times;</span>
                    <h3>Detail Transaksi: <span id="modalTransaksiId"></span></h3>
                    <p><strong>Tanggal:</strong> <span id="modalTanggalPenjualan"></span></p>
                    <p><strong>Pelanggan:</strong> <span id="modalNamaPelanggan"></span></p>
                    
                    <h4>Item Dibeli:</h4>
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Kuantitas</th>
                                    <th>Harga Satuan</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody id="modalDetailItemsBody">
                            </tbody>
                        </table>
                    </div>
                    <p><strong>Total Belanja:</strong> Rp <span id="modalTotalBelanja"></span></p>
                    <p><strong>Jumlah Uang Pelanggan:</strong> Rp <span id="modalJumlahUang"></span></p>
                    <p><strong>Kembalian:</strong> Rp <span id="modalKembalian"></span></p>
                </div>
            </div>
        `;
  }

  async afterRender() {
    this.#presenter = new transaksiPresenter({
      view: this,
      model: GoMartAPI,
    });

    await this.#presenter.initData();
    this.#setInitialTanggalPenjualan();
    this.#setupForm();
    this.#setupDetailItemHandling();
    this.#setupPaymentCalculation();
    this.#setupSearch();
    this.#setupModal();
    await this.#presenter.loadTransaksis();
  }

  #setInitialTanggalPenjualan() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('tanggalPenjualan').value = today;
  }

  resetForm() {
    const form = document.getElementById('transaksiForm');
    const submitButton = form.querySelector('.submit-transaksi');
    const cancelEditBtn = form.querySelector('#cancelEditTransaksiBtn');

    form.reset();
    form.querySelector('#idPenjualan').value = 'Otomatis';
    this.#setInitialTanggalPenjualan();
    form.querySelector('#namaPelanggan').value = '';
    form.querySelector('#totalBelanja').value = '0';
    form.querySelector('#kembalian').value = '0';
    form.querySelector('#idPelanggan').value = '';
    form.querySelector('#idBarang').value = '';
    form.querySelector('#namaBarangDetail').value = '';
    form.querySelector('#stokBarangDetail').value = '';
    form.querySelector('#hargaBarangDetail').value = '';
    form.querySelector('#kuantitasDetail').value = 1;

    this.#selectedItems = [];
    this.#editMode = false;
    this.#originalTransaksiItems = [];
    this.renderSelectedItems();

    submitButton.textContent = 'Simpan Transaksi';
    cancelEditBtn.style.display = 'none';

    document.querySelectorAll('.btn-edit-transaksi').forEach((btn) => {
      btn.style.display = 'inline-block';
    });

    document.querySelectorAll('.btn-lihat-transaksi').forEach((btn) => {
      btn.style.display = 'inline-block';
    });

    document.querySelectorAll('.btn-hapus-transaksi').forEach((btn) => {
      btn.style.display = 'inline-block';
    });
  }

  #setupForm() {
    const form = document.getElementById('transaksiForm');
    const idPelangganSelect = form.querySelector('#idPelanggan');
    const namaPelangganInput = form.querySelector('#namaPelanggan');
    const totalBelanjaInput = form.querySelector('#totalBelanja');
    const jumlahUangPelangganInput = form.querySelector('#jumlahUangPelanggan');
    const cancelEditBtn = form.querySelector('#cancelEditTransaksiBtn');

    idPelangganSelect.addEventListener('change', (e) => {
      const selectedPelanggan = this.#pelangganList.find((p) => p.id === e.target.value);
      namaPelangganInput.value = selectedPelanggan ? selectedPelanggan.namaPelanggan : '';
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const idPelanggan = idPelangganSelect.value;
      const tanggalPenjualan = document.getElementById('tanggalPenjualan').value;
      const jumlahUangPelanggan = parseFloat(jumlahUangPelangganInput.value);
      const total = parseFloat(totalBelanjaInput.value.replace(/\./g, '') || 0);

      if (this.#selectedItems.length === 0) {
        alert('Mohon tambahkan setidaknya satu item barang ke transaksi.');
        return;
      }

      if (jumlahUangPelanggan < total) {
        alert(
          `Jumlah uang pelanggan kurang. Total belanja adalah Rp ${total.toLocaleString('id-ID')}.`,
        );
        return;
      }

      const stockCheckPassed = await this.#presenter.validateStockBeforeSave(
        this.#selectedItems,
        this.#editMode ? this.#originalTransaksiItems : [],
      );
      if (!stockCheckPassed) {
        return;
      }

      const transaksiData = {
        idPelanggan,
        tanggalPenjualan,
        items: this.#selectedItems.map((item) => ({
          idBarang: item.idBarang,
          kuantitas: item.kuantitas,
        })),
        jumlahUangPelanggan,
      };

      console.log('Data yang akan dikirim ke backend:', transaksiData);

      const idPenjualanInput = document.getElementById('idPenjualan');
      const currentId = idPenjualanInput.value;

      if (this.#editMode && currentId && currentId !== 'Otomatis') {
        await this.#presenter.updateTransaksi(currentId, transaksiData);
      } else {
        await this.#presenter.addTransaksi(transaksiData);
      }
      this.resetForm();
    });

    document.getElementById('resetFormBtn').addEventListener('click', () => {
      this.resetForm();
    });

    cancelEditBtn.addEventListener('click', () => {
      this.resetForm();
    });
  }

  #setupDetailItemHandling() {
    const idBarangSelect = document.getElementById('idBarang');
    const namaBarangDetailInput = document.getElementById('namaBarangDetail');
    const stokBarangDetailInput = document.getElementById('stokBarangDetail');
    const hargaBarangDetailInput = document.getElementById('hargaBarangDetail');
    const kuantitasDetailInput = document.getElementById('kuantitasDetail');
    const addItemBtn = document.getElementById('addItemBtn');

    idBarangSelect.addEventListener('change', (e) => {
      const selectedBarang = this.#barangList.find((b) => b.id === e.target.value);
      if (selectedBarang) {
        namaBarangDetailInput.value = selectedBarang.namaBarang;
        stokBarangDetailInput.value = selectedBarang.kuantitas;
        hargaBarangDetailInput.value = selectedBarang.harga;
        kuantitasDetailInput.value = 1;

        this.#updateDisplayedStock();
      } else {
        namaBarangDetailInput.value = '';
        stokBarangDetailInput.value = '';
        hargaBarangDetailInput.value = '';
        kuantitasDetailInput.value = 1;
      }
    });

    kuantitasDetailInput.addEventListener('input', () => {
      this.#updateDisplayedStock();
    });

    addItemBtn.addEventListener('click', () => {
      const idBarang = idBarangSelect.value;
      const kuantitasToAdd = parseInt(kuantitasDetailInput.value);

      if (!idBarang || !kuantitasToAdd || kuantitasToAdd <= 0) {
        alert('Mohon pilih barang dan masukkan kuantitas yang valid (lebih dari 0).');
        return;
      }

      const selectedBarang = this.#barangList.find((b) => b.id === idBarang);
      if (!selectedBarang) {
        alert('Barang tidak ditemukan.');
        return;
      }

      const actualAvailableStock = this.#presenter.getCurrentBarangStock(idBarang);
      if (actualAvailableStock === undefined) {
        alert('Informasi stok barang tidak tersedia. Mohon coba lagi atau refresh halaman.');
        return;
      }

      const currentQuantityInCart = this.#selectedItems.reduce((sum, item) => {
        return item.idBarang === idBarang ? sum + item.kuantitas : sum;
      }, 0);

      let originalQuantityOfThisItem = 0;
      if (this.#editMode) {
        const originalItem = this.#originalTransaksiItems.find(
          (item) => item.idBarang === idBarang,
        );
        if (originalItem) {
          originalQuantityOfThisItem = originalItem.kuantitas;
        }
      }

      const effectiveStock =
        actualAvailableStock + (this.#editMode ? originalQuantityOfThisItem : 0);

      // Validasi stok
      if (currentQuantityInCart + kuantitasToAdd > effectiveStock) {
        alert(
          `Stok ${selectedBarang.namaBarang} tidak mencukupi untuk menambahkan ${kuantitasToAdd} unit. Tersedia: ${effectiveStock - currentQuantityInCart}.`,
        );
        return;
      }

      // Cek apakah barang sudah ada di daftar item transaksi
      const existingItemIndex = this.#selectedItems.findIndex((item) => item.idBarang === idBarang);

      if (existingItemIndex > -1) {
        // Jika sudah ada, update kuantitas dan subtotal
        this.#selectedItems[existingItemIndex].kuantitas += kuantitasToAdd;
        this.#selectedItems[existingItemIndex].subtotal =
          this.#selectedItems[existingItemIndex].kuantitas * selectedBarang.harga;
      } else {
        // Jika belum ada, tambahkan sebagai item baru
        this.#selectedItems.push({
          idBarang: selectedBarang.id,
          namaBarang: selectedBarang.namaBarang,
          kuantitas: kuantitasToAdd,
          harga: selectedBarang.harga,
          subtotal: kuantitasToAdd * selectedBarang.harga,
        });
      }
      this.renderSelectedItems();
      this.updateTotal();
      this.#updateDisplayedStock(); // Update stok yang ditampilkan setelah item ditambahkan

      // Reset detail item selection
      idBarangSelect.value = '';
      namaBarangDetailInput.value = '';
      stokBarangDetailInput.value = '';
      hargaBarangDetailInput.value = '';
      kuantitasDetailInput.value = 1;
    });
  }

  #updateDisplayedStock() {
    const idBarangSelect = document.getElementById('idBarang');
    const stokBarangDetailInput = document.getElementById('stokBarangDetail');
    const kuantitasDetailInput = document.getElementById('kuantitasDetail');

    const selectedIdBarang = idBarangSelect.value;
    if (selectedIdBarang) {
      const actualAvailableStock = this.#presenter.getCurrentBarangStock(selectedIdBarang);
      let currentQuantityInCart = this.#selectedItems.reduce((sum, item) => {
        return item.idBarang === selectedIdBarang ? sum + item.kuantitas : sum;
      }, 0);

      let originalQuantityOfThisItem = 0;
      if (this.#editMode) {
        const originalItem = this.#originalTransaksiItems.find(
          (item) => item.idBarang === selectedIdBarang,
        );
        if (originalItem) {
          originalQuantityOfThisItem = originalItem.kuantitas;
        }
      }

      const effectiveStock =
        actualAvailableStock + (this.#editMode ? originalQuantityOfThisItem : 0);

      // Tampilkan sisa stok yang bisa ditambahkan
      const remainingStock = effectiveStock - currentQuantityInCart;
      stokBarangDetailInput.value = remainingStock >= 0 ? remainingStock : 0;

      // Atur max kuantitas yang bisa diinput
      kuantitasDetailInput.max = remainingStock;
      if (parseInt(kuantitasDetailInput.value) > remainingStock) {
        kuantitasDetailInput.value = remainingStock > 0 ? remainingStock : 0;
      }
    } else {
      stokBarangDetailInput.value = '';
      kuantitasDetailInput.max = '';
    }
  }

  #setupPaymentCalculation() {
    const jumlahUangPelangganInput = document.getElementById('jumlahUangPelanggan');
    jumlahUangPelangganInput.addEventListener('input', () => {
      this.updateKembalian();
    });
  }

  #setupSearch() {
    const searchInput = document.getElementById('searchTransaksiInput');
    searchInput.addEventListener('input', (e) => {
      const keyword = e.target.value.toLowerCase();
      this.#presenter.filterTransaksis(keyword);
    });
  }

  #setupModal() {
    const modal = document.getElementById('transaksiDetailModal');
    const closeButton = document.querySelector('.close-button');

    closeButton.addEventListener('click', () => {
      modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    });
  }

  renderPelangganOptions(pelanggans) {
    this.#pelangganList = pelanggans;
    const selectElement = document.getElementById('idPelanggan');
    selectElement.innerHTML = '<option value="">-- Pilih Pelanggan --</option>';
    pelanggans.forEach((pelanggan) => {
      const option = document.createElement('option');
      option.value = pelanggan.id;
      option.textContent = pelanggan.namaPelanggan;
      selectElement.appendChild(option);
    });
  }

  renderBarangOptions(barangs) {
    this.#barangList = barangs;
    const selectElement = document.getElementById('idBarang');
    selectElement.innerHTML = '<option value="">-- Pilih Barang --</option>';
    barangs.forEach((barang) => {
      const option = document.createElement('option');
      option.value = barang.id;

      option.textContent = `${barang.namaBarang} (Stok: ${barang.kuantitas}, Rp ${barang.harga.toLocaleString('id-ID')})`;
      selectElement.appendChild(option);
    });
  }

  renderSelectedItems() {
    const tbody = document.getElementById('transaksiDetailTableBody');
    tbody.innerHTML = '';
    if (this.#selectedItems.length === 0) {
      tbody.innerHTML =
        '<tr><td colspan="6" style="text-align: center;">Belum ada item ditambahkan.</td></tr>';
      return;
    }

    this.#selectedItems.forEach((item, index) => {
      const row = document.createElement('tr');
      row.innerHTML = `
                <td>${item.idBarang}</td>
                <td>${item.namaBarang}</td>
                <td>
                    <input type="number" class="item-kuantitas-input" data-index="${index}" value="${item.kuantitas}" min="1">
                </td>
                <td>${item.harga.toLocaleString('id-ID')}</td>
                <td>${item.subtotal.toLocaleString('id-ID')}</td>
                <td>
                    <button class="btn-remove-item" data-index="${index}">Hapus</button>
                </td>
            `;
      tbody.appendChild(row);
    });

    document.querySelectorAll('.btn-remove-item').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        const index = parseInt(e.target.dataset.index);
        this.#selectedItems.splice(index, 1);
        this.renderSelectedItems();
        this.updateTotal();
        this.#updateDisplayedStock();
      });
    });

    // Event listener untuk perubahan kuantitas di tabel detail
    document.querySelectorAll('.item-kuantitas-input').forEach((input) => {
      input.addEventListener('change', (e) => {
        const index = parseInt(e.target.dataset.index);
        let newKuantitas = parseInt(e.target.value);

        if (isNaN(newKuantitas) || newKuantitas <= 0) {
          alert('Kuantitas harus angka positif.');
          e.target.value = this.#selectedItems[index].kuantitas;
          return;
        }

        const itemToUpdate = this.#selectedItems[index];
        const idBarang = itemToUpdate.idBarang;
        const selectedBarang = this.#barangList.find((b) => b.id === idBarang);

        const actualAvailableStock = this.#presenter.getCurrentBarangStock(idBarang);
        let originalQuantityOfThisItem = 0;
        if (this.#editMode) {
          const originalItem = this.#originalTransaksiItems.find(
            (item) => item.idBarang === idBarang,
          );
          if (originalItem) {
            originalQuantityOfThisItem = originalItem.kuantitas;
          }
        }
        const effectiveStock =
          actualAvailableStock + (this.#editMode ? originalQuantityOfThisItem : 0);

        if (newKuantitas > effectiveStock) {
          alert(`Stok ${selectedBarang.namaBarang} hanya tersedia ${effectiveStock}.`);
          e.target.value = itemToUpdate.kuantitas;
          return;
        }

        itemToUpdate.kuantitas = newKuantitas;
        itemToUpdate.subtotal = newKuantitas * itemToUpdate.harga;
        this.renderSelectedItems();
        this.updateTotal();
        this.#updateDisplayedStock();
      });
    });
  }

  updateTotal() {
    const totalBelanjaInput = document.getElementById('totalBelanja');
    const newTotal = this.#selectedItems.reduce((sum, item) => sum + item.subtotal, 0);
    totalBelanjaInput.value = newTotal.toLocaleString('id-ID');
    this.updateKembalian();
  }

  updateKembalian() {
    const totalBelanja = parseFloat(
      document.getElementById('totalBelanja').value.replace(/\./g, '') || 0,
    );
    const jumlahUangPelanggan = parseFloat(
      document.getElementById('jumlahUangPelanggan').value || 0,
    );
    const kembalian = jumlahUangPelanggan - totalBelanja;
    document.getElementById('kembalian').value = kembalian.toLocaleString('id-ID');
  }

  tampilkanTransaksi(transaksis) {
    const tbody = document.getElementById('transaksiTableBody');
    tbody.innerHTML = '';

    if (!transaksis || transaksis.length === 0) {
      tbody.innerHTML =
        '<tr><td colspan="5" style="text-align: center;">Tidak ada data transaksi.</td></tr>';
      return;
    }

    transaksis.forEach((transaksi) => {
      const row = document.createElement('tr');
      row.innerHTML = `
                <td>${transaksi.idPenjualan}</td>
                <td>${new Date(transaksi.tanggalPenjualan).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</td>
                <td>${transaksi.namaPelanggan}</td>
                <td>${transaksi.total.toLocaleString('id-ID')}</td>
                <td class="actions">
                    <button class="btn-lihat-transaksi" data-id="${transaksi.idPenjualan}">Lihat</button>
                    <button class="btn-edit-transaksi" data-id="${transaksi.idPenjualan}">Edit</button>
                    <button class="btn-hapus-transaksi" data-id="${transaksi.idPenjualan}">Hapus</button>
                </td>
            `;
      tbody.appendChild(row);
    });

    document.querySelectorAll('.btn-hapus-transaksi').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.id;
        const row = btn.closest('tr');
        const namaPelangganCell = row ? row.children[2].textContent : 'transaksi ini';
        if (confirm(`Anda yakin ingin menghapus transaksi ${namaPelangganCell} (ID: ${id})?`)) {
          await this.#presenter.deleteTransaksi(id);
        }
      });
    });

    document.querySelectorAll('.btn-edit-transaksi').forEach((btn) => {
      btn.addEventListener('click', async () => {
        document
          .querySelectorAll('.btn-edit-transaksi, .btn-hapus-transaksi, .btn-lihat-transaksi')
          .forEach((otherBtn) => {
            otherBtn.style.display = 'none';
          });

        const id = btn.dataset.id;
        await this.#presenter.editTransaksi(id);
      });
    });

    document.querySelectorAll('.btn-lihat-transaksi').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.id;
        await this.#presenter.showTransaksiDetail(id);
      });
    });
  }

  fillFormForEdit(transaksi) {
    const form = document.getElementById('transaksiForm');
    const submitButton = form.querySelector('.submit-transaksi');
    const cancelEditBtn = form.querySelector('#cancelEditTransaksiBtn');

    this.#editMode = true;
    this.#originalTransaksiItems = JSON.parse(JSON.stringify(transaksi.items));

    form.querySelector('#idPenjualan').value = transaksi.idPenjualan;
    form.querySelector('#tanggalPenjualan').value = new Date(transaksi.tanggalPenjualan)
      .toISOString()
      .split('T')[0];
    form.querySelector('#idPelanggan').value = transaksi.idPelanggan;
    form.querySelector('#namaPelanggan').value = transaksi.namaPelanggan;

    this.#selectedItems = transaksi.items.map((item) => ({
      idBarang: item.idBarang,
      namaBarang: item.namaBarang,
      kuantitas: item.kuantitas,
      harga: item.harga,
      subtotal: item.subtotal,
    }));
    this.renderSelectedItems();
    this.updateTotal();

    form.querySelector('#jumlahUangPelanggan').value = transaksi.jumlahUangPelanggan;
    this.updateKembalian();
    submitButton.textContent = 'Update Transaksi';
    cancelEditBtn.style.display = 'inline-block';
  }

  showDetailModal(transaksi) {
    const modal = document.getElementById('transaksiDetailModal');
    document.getElementById('modalTransaksiId').textContent = transaksi.idPenjualan;
    document.getElementById('modalTanggalPenjualan').textContent = new Date(
      transaksi.tanggalPenjualan,
    ).toLocaleString('id-ID', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    document.getElementById('modalNamaPelanggan').textContent = transaksi.namaPelanggan;
    document.getElementById('modalTotalBelanja').textContent =
      transaksi.total.toLocaleString('id-ID');
    document.getElementById('modalJumlahUang').textContent =
      transaksi.jumlahUangPelanggan.toLocaleString('id-ID');
    document.getElementById('modalKembalian').textContent =
      transaksi.kembalian.toLocaleString('id-ID');

    const modalDetailItemsBody = document.getElementById('modalDetailItemsBody');
    modalDetailItemsBody.innerHTML = '';
    transaksi.items.forEach((item) => {
      const row = document.createElement('tr');
      row.innerHTML = `
                <td>${item.idBarang}</td>
                <td>${item.namaBarang}</td>
                <td>${item.kuantitas}</td>
                <td>${item.harga.toLocaleString('id-ID')}</td>
                <td>${item.subtotal.toLocaleString('id-ID')}</td>
            `;
      modalDetailItemsBody.appendChild(row);
    });

    modal.style.display = 'flex';
  }
}
