// src/pages/transaksi/transaksi-presenter.js
export default class TransaksiPresenter {
  #view;
  #model;
  #allTransaksis = [];
  #currentBarangStock = {};

  constructor({ view, model }) {
    this.#view = view;
    this.#model = model;
  }

  async initData() {
    const pelangganResponse = await this.#model.getAllPelanggan();
    if (pelangganResponse.ok && pelangganResponse.data) {
      this.#view.renderPelangganOptions(pelangganResponse.data);
    } else {
      alert('Gagal memuat data pelanggan.');
    }

    await this.loadBarangForStockValidation();
  }

  async loadBarangForStockValidation() {
    const barangResponse = await this.#model.getAllBarang();
    if (barangResponse.ok && barangResponse.data) {
      this.#view.renderBarangOptions(barangResponse.data);
      this.#currentBarangStock = {};
      barangResponse.data.forEach((barang) => {
        this.#currentBarangStock[barang.id] = barang.kuantitas;
      });
    } else {
      alert('Gagal memuat data barang.');
    }
  }

  getCurrentBarangStock(idBarang) {
    return this.#currentBarangStock[idBarang];
  }

  async validateStockBeforeSave(selectedItems, originalItems = []) {
    await this.loadBarangForStockValidation();

    for (const item of selectedItems) {
      const idBarang = item.idBarang;
      const requestedQuantity = item.kuantitas;
      const currentStock = this.#currentBarangStock[idBarang];

      const originalItem = originalItems.find((orig) => orig.idBarang === idBarang);
      const originalQuantity = originalItem ? originalItem.kuantitas : 0;

      const effectiveStock = currentStock + originalQuantity;

      if (requestedQuantity > effectiveStock) {
        alert(
          `Gagal menyimpan transaksi: Stok ${item.namaBarang} tidak mencukupi. Tersedia: ${effectiveStock}, Diminta: ${requestedQuantity}.`,
        );
        return false;
      }
    }
    return true;
  }

  async loadTransaksis() {
    const response = await this.#model.getAllTransaksiAPI();
    if (response.ok && response.data) {
      this.#allTransaksis = response.data;
      this.#view.tampilkanTransaksi(this.#allTransaksis);
    } else {
      alert('Gagal memuat data transaksi dari server.');
      this.#view.tampilkanTransaksi([]);
    }
  }

  async addTransaksi(transaksiData) {
    const response = await this.#model.storeNewTransaksi(transaksiData);
    if (response.ok) {
      alert(response.message || 'Transaksi berhasil ditambahkan!');
      await this.loadTransaksis();
      await this.loadBarangForStockValidation();
    } else {
      alert(response.message || 'Gagal menambahkan transaksi! ' + (response.message || ''));
    }
  }

  async updateTransaksi(id, transaksiData) {
    const response = await this.#model.updateTransaksiAPI(id, transaksiData);
    if (response.ok) {
      alert(response.message || 'Transaksi berhasil diperbarui!');
      await this.loadTransaksis();
      await this.loadBarangForStockValidation();
    } else {
      alert(response.message || 'Gagal memperbarui transaksi! ' + (response.message || ''));
    }
  }

  async deleteTransaksi(id) {
    const response = await this.#model.deleteTransaksiAPI(id);
    if (response.ok) {
      alert(response.message || 'Transaksi berhasil dihapus!');
      await this.loadTransaksis();
      await this.loadBarangForStockValidation();
    } else {
      alert(response.message || 'Gagal menghapus transaksi! ' + (response.message || ''));
    }
  }

  async editTransaksi(id) {
    const response = await this.#model.getTransaksiByIdAPI(id);
    if (response.ok && response.data) {
      this.#view.fillFormForEdit(response.data);
    } else {
      alert(response.message || 'Gagal mengambil data transaksi untuk diedit!');
    }
  }

  async showTransaksiDetail(id) {
    const response = await this.#model.getTransaksiByIdAPI(id);
    if (response.ok && response.data) {
      this.#view.showDetailModal(response.data);
    } else {
      alert(response.message || 'Gagal mengambil detail transaksi!');
    }
  }

  filterTransaksis(keyword) {
    if (!keyword) {
      this.#view.tampilkanTransaksi(this.#allTransaksis);
      return;
    }

    const filtered = this.#allTransaksis.filter(
      (transaksi) =>
        transaksi.idPenjualan.toLowerCase().includes(keyword) ||
        transaksi.namaPelanggan.toLowerCase().includes(keyword) ||
        new Date(transaksi.tanggalPenjualan)
          .toLocaleDateString('id-ID')
          .toLowerCase()
          .includes(keyword),
    );
    this.#view.tampilkanTransaksi(filtered);
  }
}
