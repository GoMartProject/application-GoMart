import * as GoMartAPI from '../../data/api';
import LaporanPenjualanPresenter from './laporan-penjualan-presenter';

export default class LaporanPenjualanPage {
  #presenter;

  async render() {
    return `
            <div class="container-laporan">
                <h2>Laporan Penjualan</h2>

                <div class="filter-section">
                    <div class="form-control">
                        <label for="startDate">Tanggal Mulai:</label>
                        <input type="date" id="startDate" class="filter-input">
                    </div>
                    <div class="form-control">
                        <label for="endDate">Tanggal Akhir:</label>
                        <input type="date" id="endDate" class="filter-input">
                    </div>
                    <div class="filter-buttons">
                        <button id="filterLaporanBtn" class="btn btn-primary">Filter Laporan</button>
                        <button id="downloadCsvBtn" class="btn btn-success">Unduh CSV</button>
                    </div>
                </div>

                <hr>

                <h3>Ringkasan Laporan</h3>
                <div class="summary-info">
                    <p>Total Transaksi: <strong id="totalTransaksiCount">0</strong></p>
                    <p>Total Pendapatan: Rp <strong id="totalPendapatan">0</strong></p>
                </div>

                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>ID Penjualan</th>
                                <th>Tanggal</th>
                                <th>Pelanggan</th>
                                <th>Total Belanja</th>
                                <th>Detail Item</th>
                            </tr>
                        </thead>
                        <tbody id="laporanTableBody">
                            <tr><td colspan="5" style="text-align: center;">Pilih tanggal dan filter untuk melihat laporan.</td></tr>
                        </tbody>
                    </table>
                </div>

                <div id="laporanDetailModal" class="modal">
                    <div class="modal-content">
                        <span class="close-button">&times;</span>
                        <h3>Detail Transaksi: <span id="modalLaporanTransaksiId"></span></h3>
                        <p><strong>Tanggal:</strong> <span id="modalLaporanTanggalPenjualan"></span></p>
                        <p><strong>Pelanggan:</strong> <span id="modalLaporanNamaPelanggan"></span></p>
                        
                        <h4>Item Dibeli:</h4>
                        <div class="table-wrapper">
                            <table>
                                <thead>
                                    <tr>
                                        <th>ID Barang</th>
                                        <th>Nama Barang</th>
                                        <th>Kuantitas</th>
                                        <th>Harga Satuan</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody id="modalLaporanDetailItemsBody">
                                </tbody>
                            </table>
                        </div>
                        <p><strong>Total Belanja:</strong> Rp <span id="modalLaporanTotalBelanja"></span></p>
                        <p><strong>Jumlah Uang Pelanggan:</strong> Rp <span id="modalLaporanJumlahUang"></span></p>
                        <p><strong>Kembalian:</strong> Rp <span id="modalLaporanKembalian"></span></p>
                    </div>
                </div>
            </div>
        `;
  }

  async afterRender() {
    this.#presenter = new LaporanPenjualanPresenter({
      view: this,
      model: GoMartAPI,
    });

    this.#setInitialFilterDates();
    this.#setupEventListeners();
    this.#setupModal();
    await this.#presenter.filterLaporan(); // Load initial report
  }

  #setInitialFilterDates() {
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)
      .toISOString()
      .split('T')[0];
    const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0)
      .toISOString()
      .split('T')[0];

    document.getElementById('startDate').value = firstDayOfMonth;
    document.getElementById('endDate').value = lastDayOfMonth;
  }

  #setupEventListeners() {
    document.getElementById('filterLaporanBtn').addEventListener('click', () => {
      this.#presenter.filterLaporan();
    });

    document.getElementById('downloadCsvBtn').addEventListener('click', () => {
      this.#presenter.downloadLaporanCsv();
    });
  }

  #setupModal() {
    const modal = document.getElementById('laporanDetailModal');
    const closeButton = modal.querySelector('.close-button');

    closeButton.addEventListener('click', () => {
      modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    });
  }

  getFilterDates() {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    return { startDate, endDate };
  }

  tampilkanLaporan(laporanData) {
    const tbody = document.getElementById('laporanTableBody');
    tbody.innerHTML = '';

    if (!laporanData || laporanData.length === 0) {
      tbody.innerHTML =
        '<tr><td colspan="5" style="text-align: center;">Tidak ada data laporan untuk periode ini.</td></tr>';
      document.getElementById('totalTransaksiCount').textContent = '0';
      document.getElementById('totalPendapatan').textContent = '0';
      return;
    }

    let totalPendapatan = 0;

    laporanData.forEach((transaksi) => {
      const row = document.createElement('tr');
      row.innerHTML = `
                <td>${transaksi.idPenjualan}</td>
                <td>${new Date(transaksi.tanggalPenjualan).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</td>
                <td>${transaksi.namaPelanggan}</td>
                <td>${transaksi.total.toLocaleString('id-ID')}</td>
                <td class="actions">
                    <button class="btn-lihat-laporan-detail" data-id="${transaksi.idPenjualan}">Lihat Detail</button>
                </td>
            `;
      tbody.appendChild(row);
      totalPendapatan += transaksi.total;
    });

    document.getElementById('totalTransaksiCount').textContent = laporanData.length;
    document.getElementById('totalPendapatan').textContent =
      totalPendapatan.toLocaleString('id-ID');

    document.querySelectorAll('.btn-lihat-laporan-detail').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        const id = e.target.dataset.id;
        this.#presenter.showLaporanDetail(id);
      });
    });
  }

  showDetailModal(transaksi) {
    const modal = document.getElementById('laporanDetailModal');
    document.getElementById('modalLaporanTransaksiId').textContent = transaksi.idPenjualan;

    const tanggalFormatted = new Date(transaksi.tanggalPenjualan).toLocaleString('id-ID', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    document.getElementById('modalLaporanTanggalPenjualan').textContent = tanggalFormatted;

    document.getElementById('modalLaporanNamaPelanggan').textContent = transaksi.namaPelanggan;
    document.getElementById('modalLaporanTotalBelanja').textContent =
      transaksi.total.toLocaleString('id-ID');
    document.getElementById('modalLaporanJumlahUang').textContent =
      transaksi.jumlahUangPelanggan.toLocaleString('id-ID');
    document.getElementById('modalLaporanKembalian').textContent =
      transaksi.kembalian.toLocaleString('id-ID');

    const modalDetailItemsBody = document.getElementById('modalLaporanDetailItemsBody');
    modalDetailItemsBody.innerHTML = '';
    transaksi.items.forEach((item) => {
      const row = document.createElement('tr');
      row.innerHTML = `
                <td>${item.idBarang || '-'}</td> 
                <td>${item.namaBarang}</td>
                <td>${item.kuantitas}</td>
                <td>${item.harga.toLocaleString('id-ID')}</td>
                <td>${item.subtotal.toLocaleString('id-ID')}</td>
            `;
      modalDetailItemsBody.appendChild(row);
    });

    modal.style.display = 'flex';
  }

  showLoading() {
    const tbody = document.getElementById('laporanTableBody');
    tbody.innerHTML = '<tr><td colspan="5" style="text-align: center;">Memuat laporan...</td></tr>';
    document.getElementById('totalTransaksiCount').textContent = '0';
    document.getElementById('totalPendapatan').textContent = '0';
  }

  showError(message) {
    const tbody = document.getElementById('laporanTableBody');
    tbody.innerHTML = `<tr><td colspan="5" style="color: red; text-align: center;">${message}</td></tr>`;
    document.getElementById('totalTransaksiCount').textContent = '0';
    document.getElementById('totalPendapatan').textContent = '0';
  }
}
