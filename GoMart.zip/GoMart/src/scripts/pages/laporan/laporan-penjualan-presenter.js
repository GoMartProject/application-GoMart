export default class LaporanPenjualanPresenter {
  #view;
  #model;
  #laporanData = [];

  constructor({ view, model }) {
    this.#view = view;
    this.#model = model;
  }

  #validateDates(startDate, endDate) {
    if (!startDate || !endDate) {
      this.#view.showError('Mohon pilih tanggal mulai dan tanggal akhir.');
      return false;
    }

    const start = new Date(startDate);
    const end = new Date(endDate);

    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      this.#view.showError('Format tanggal tidak valid. Mohon gunakan format YYYY-MM-DD.');
      return false;
    }

    end.setHours(23, 59, 59, 999);

    if (start > end) {
      this.#view.showError('Tanggal mulai tidak boleh lebih besar dari tanggal akhir.');
      return false;
    }
    return true;
  }

  async filterLaporan() {
    this.#view.showLoading();
    const { startDate, endDate } = this.#view.getFilterDates();

    if (!this.#validateDates(startDate, endDate)) {
      return;
    }

    try {
      const response = await this.#model.getLaporanPenjualanAPI({ startDate, endDate });
      if (response.ok && response.data) {
        this.#laporanData = response.data.transaksi || [];
        this.#view.tampilkanLaporan(this.#laporanData);
      } else {
        this.#view.showError(
          response.message || 'Gagal memuat laporan penjualan. Silakan coba lagi.',
        );
        this.#laporanData = [];
      }
    } catch (error) {
      console.error('Error fetching sales report:', error);
      this.#view.showError(
        'Terjadi kesalahan saat mengambil laporan. Pastikan server berjalan dan data tersedia.',
      );
      this.#laporanData = [];
    }
  }

  async downloadLaporanCsv() {
    const { startDate, endDate } = this.#view.getFilterDates();

    if (!this.#validateDates(startDate, endDate)) {
      alert('Mohon perbaiki tanggal untuk mengunduh laporan.');
      return;
    }

    if (this.#laporanData.length === 0) {
      await this.filterLaporan();
      if (this.#laporanData.length === 0) {
        alert('Tidak ada data laporan untuk diunduh sebagai CSV pada periode ini.');
        return;
      }
    }

    // Header CSV
    const headers = [
      'ID Penjualan',
      'Tanggal',
      'Nama Pelanggan',
      'Total Belanja',
      'Jumlah Uang Pelanggan',
      'Kembalian',
      'Detail Item (Nama Barang, Kuantitas, Harga Satuan, Subtotal)',
    ].join(',');

    // Baris data CSV
    const rows = this.#laporanData.map((t) => {
      const itemDetails = t.items
        .map(
          (item) =>
            `${item.namaBarang} (ID: ${item.idBarang || 'N/A'}, ${item.kuantitas}x @Rp${item.harga.toLocaleString('id-ID')}) = Rp${item.subtotal.toLocaleString('id-ID')}`,
        )
        .join('; ');

      return [
        `"${t.idPenjualan}"`,
        `"${new Date(t.tanggalPenjualan).toLocaleString('id-ID')}"`,
        `"${t.namaPelanggan}"`,
        `"${t.total.toLocaleString('id-ID')}"`,
        `"${t.jumlahUangPelanggan.toLocaleString('id-ID')}"`,
        `"${t.kembalian.toLocaleString('id-ID')}"`,
        `"${itemDetails}"`,
      ]
        .map((col) => col.replace(/"/g, '""'))
        .join(',');
    });

    // Gabungkan header dan baris data
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);

    // Nama file CSV
    const formattedStartDate = new Date(startDate).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    const formattedEndDate = new Date(endDate).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    link.setAttribute('href', url);
    link.setAttribute(
      'download',
      `laporan_penjualan_${formattedStartDate}_${formattedEndDate}.csv`,
    );
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    alert('Laporan CSV berhasil diunduh!');
  }

  showLaporanDetail(id) {
    const transaksi = this.#laporanData.find((t) => t.idPenjualan === id);
    if (transaksi) {
      this.#view.showDetailModal(transaksi);
    } else {
      alert('Detail transaksi tidak ditemukan.');
    }
  }
}
