export default class masterBarangPresenter {
  #view;
  #model;
  #allBarangs = [];

  constructor({ view, model }) {
    this.#view = view;
    this.#model = model;
  }

  async loadBarang() {
    const response = await this.#model.getAllBarang();
    if (response.ok && response.data) {
      this.#allBarangs = response.data;
      this.#view.tampilkanBarang(this.#allBarangs);
    } else {
      alert('Gagal memuat data barang dari server');
      this.#view.tampilkanBarang([]);
    }
  }

  async tambahBarang(barang) {
    const { namaBarang, kuantitas, harga, satuan, kategori } = barang;
    const response = await this.#model.storeNewBarang({
      namaBarang,
      kuantitas,
      harga,
      satuan,
      kategori,
    });

    if (response.ok) {
      alert(response.message || 'Barang berhasil ditambahkan');
      await this.loadBarang();
    } else {
      alert(response.message || 'Gagal menambahkan barang');
    }
  }

  async hapusBarang(id) {
    const response = await this.#model.deleteBarangById(id);
    if (response.ok) {
      alert(response.message || 'Barang berhasil dihapus');
      await this.loadBarang();
    } else {
      alert(response.message || 'Gagal menghapus barang');
    }
  }

  async updateBarang(barang) {
    const response = await this.#model.updateBarang(barang);
    if (response.ok) {
      alert(response.message || 'Barang berhasil diperbarui');
      await this.loadBarang(); // Refresh table
    } else {
      alert(response.message || 'Gagal memperbarui barang');
    }
  }

  filterBarang(keyword) {
    if (!keyword) {
      this.#view.tampilkanBarang(this.#allBarangs);
      return;
    }

    const filteredBarang = this.#allBarangs.filter(
      (barang) =>
        barang.id.toLowerCase().includes(keyword) ||
        barang.namaBarang.toLowerCase().includes(keyword),
    );
    this.#view.tampilkanBarang(filteredBarang);
  }

  isBarangNameDuplicate(namaBarang) {
    return this.#allBarangs.some(
      (barang) => barang.namaBarang.toLowerCase() === namaBarang.toLowerCase(),
    );
  }
}
