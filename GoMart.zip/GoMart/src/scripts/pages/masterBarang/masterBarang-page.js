import * as GoMartAPI from '../../data/api';
import masterBarangPresenter from './masterBarang-presenter';

export default class masterBarangPage {
  #presenter;
  #editMode = false;
  #editId = null;
  #editNamaBarang = null;

  async render() {
    return `
            <div class="containermasterbarang">
                <h2>Master Barang</h2>

                <form id="barangForm" class="barangForm">
                    <div class="form-control">
                        <label for="idbarang">ID Barang</label>
                        <div class="barang-form_title-container">
                            <input type="text" id="idbarang" placeholder="ID akan otomatis terisi" disabled required />
                        </div>
                    </div>

                    <div class="form-control">
                        <label for="namaBarang">Nama Barang</label>
                        <div class="barang-form_title-container">
                            <input type="text" id="namaBarang" placeholder="Nama Barang" required />
                        </div>
                    </div>

                    <div class="form-control">
                        <label for="kuantitas">Kuantitas</label>
                        <div class="barang-form_title-container">
                            <input type="number" id="kuantitas" placeholder="1" required />
                        </div>
                    </div>

                    <div class="form-control">
                        <label for="harga">Harga</label>
                        <div class="barang-form_title-container">
                            <input type="number" id="harga" placeholder="Harga" required />
                        </div>
                    </div>

                    <div class="form-control">
                        <label for="satuan">Satuan</label>
                        <div class="barang-form_title-container">
                            <select id="satuan" required>
                                <option value="">-- Pilih Satuan --</option>
                                <option value="kg">kg</option>
                                <option value="gram">gram</option>
                                <option value="ons">ons</option>
                                <option value="pcs">pcs</option>
                                <option value="liter">liter</option>
                                <option value="buah">buah</option>
                                <option value="sachet">sachet</option>
                                <option value="kotak">kotak</option>
                                <option value="renteng">renteng</option>
                                <option value="papan">papan</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-control">
                        <label for="kategori">Kategori</label>
                        <div class="barang-form_title-container">
                            <select id="kategori" required>
                                <option value="">-- Pilih Kategori --</option>
                                <option value="makanan">makanan</option>
                                <option value="minuman">minuman</option>
                                <option value="perlengkapan">perlengkapan</option>
                                <option value="bahanbaku">bahanbaku</option>
                            </select>
                        </div>
                    </div>

                    <div class="barang-form-buttons">
                        <button type="submit" class="submit-barang btn">Tambah Barang</button>
                    </div>
                </form>

                <div class="barang-search">
                    <input
                        type="text"
                        id="searchInput"
                        placeholder="Cari berdasarkan ID atau Nama Barang..."
                    />
                </div>

                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Qty</th>
                                <th>Harga</th>
                                <th>Satuan</th>
                                <th>Kategori</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="barangTableBody">
                        </tbody>
                    </table>
                </div>
            </div>
        `;
  }

  async afterRender() {
    this.#presenter = new masterBarangPresenter({
      view: this,
      model: GoMartAPI,
    });

    this.#setupForm();
    this.#setupSearch();
    await this.#presenter.loadBarang();
  }

  resetFormToTambahMode() {
    const form = document.getElementById('barangForm');
    const buttonSubmit = form.querySelector('button[type="submit"]');
    const idInput = form.querySelector('#idbarang');
    const namaBarangInput = form.querySelector('#namaBarang');

    this.#editMode = false;
    this.#editId = null;
    this.#editNamaBarang = null;
    form.reset();
    namaBarangInput.disabled = false;
    buttonSubmit.textContent = 'Tambah Barang';
    idInput.value = '';
    form.querySelector('#satuan').value = '';
    form.querySelector('#kategori').value = '';

    document.querySelectorAll('.btn-edit').forEach((btn) => {
      btn.style.display = 'inline-block';
    });
    document.querySelectorAll('.btn-cancel-row-edit').forEach((btn) => {
      btn.style.display = 'none';
    });
  }

  #setupForm() {
    const form = document.getElementById('barangForm');
    const buttonSubmit = form.querySelector('button[type="submit"]');
    const idInput = form.querySelector('#idbarang');
    const namaBarangInput = form.querySelector('#namaBarang');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const namaBarang = namaBarangInput.value;
      const kuantitas = parseInt(form.querySelector('#kuantitas').value);
      const harga = parseFloat(form.querySelector('#harga').value);
      const satuan = form.querySelector('#satuan').value;
      const kategori = form.querySelector('#kategori').value;

      if (!this.#editMode && this.#presenter.isBarangNameDuplicate(namaBarang)) {
        alert('Nama Barang sudah ada.');
        return;
      }

      const barangData = {
        ...(this.#editMode && { id: this.#editId }),
        namaBarang,
        kuantitas,
        harga,
        satuan,
        kategori,
      };

      if (this.#editMode) {
        await this.#presenter.updateBarang(barangData);
      } else {
        await this.#presenter.tambahBarang(barangData);
      }

      this.resetFormToTambahMode();
    });
  }

  #setupSearch() {
    const searchInput = document.getElementById('searchInput');
    searchInput.addEventListener('input', (e) => {
      const keyword = e.target.value.toLowerCase();
      this.#presenter.filterBarang(keyword);
    });
  }

  tampilkanBarang(barangs) {
    const tbody = document.getElementById('barangTableBody');
    tbody.innerHTML = '';

    if (!barangs || barangs.length === 0) {
      tbody.innerHTML =
        '<tr><td colspan="7" style="text-align: center;">Tidak ada data barang.</td></tr>';
      return;
    }

    barangs.forEach((barang) => {
      const row = document.createElement('tr');

      row.innerHTML = `
                <td>${barang.id}</td>
                <td>${barang.namaBarang}</td>
                <td>${barang.kuantitas}</td>
                <td>${barang.harga}</td>
                <td>${barang.satuan}</td>
                <td>${barang.kategori}</td>
                <td class="actions">
                    <button class="btn-hapus" data-id="${barang.id}">Hapus</button>
                    <button class="btn-edit" data-id="${barang.id}">Edit</button>
                    <button class="btn-cancel-row-edit btn" data-id="${barang.id}" style="display: none;">Batal</button>
                </td>
            `;

      tbody.appendChild(row);
    });

    document.querySelectorAll('.btn-hapus').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.id;
        const row = btn.closest('tr');
        const namaBarangCell = row ? row.children[1].textContent : 'barang ini';
        const confirmDelete = confirm(
          `Apakah Anda yakin ingin menghapus barang "${namaBarangCell}" (ID: ${id})?`,
        );
        if (confirmDelete) {
          await this.#presenter.hapusBarang(id);
        }
      });
    });

    document.querySelectorAll('.btn-edit').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.resetFormToTambahMode();

        const form = document.getElementById('barangForm');
        const buttonSubmit = form.querySelector('button[type="submit"]');
        const id = btn.dataset.id;
        const barang = barangs.find((b) => b.id === id);

        if (barang) {
          btn.style.display = 'none';

          const cancelRowButton = btn.parentNode.querySelector('.btn-cancel-row-edit');
          if (cancelRowButton) {
            cancelRowButton.style.display = 'inline-block';
          }

          form.querySelector('#idbarang').value = barang.id;
          form.querySelector('#namaBarang').value = barang.namaBarang;
          form.querySelector('#namaBarang').disabled = true;
          form.querySelector('#kuantitas').value = barang.kuantitas;
          form.querySelector('#harga').value = barang.harga;
          form.querySelector('#satuan').value = barang.satuan;
          form.querySelector('#kategori').value = barang.kategori;

          this.#editMode = true;
          this.#editId = barang.id;
          this.#editNamaBarang = barang.namaBarang;

          buttonSubmit.textContent = 'Simpan Perubahan';
        }
      });
    });

    document.querySelectorAll('.btn-cancel-row-edit').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.resetFormToTambahMode();
      });
    });
  }
}
