export default class masterPelangganPresenter {
  #view;
  #model;
  #allPelanggans = [];

  constructor({ view, model }) {
    this.#view = view;
    this.#model = model;
  }

  async loadPelanggan() {
    const response = await this.#model.getAllPelanggan();
    if (response.ok && response.data) {
      this.#allPelanggans = response.data;
      this.#view.tampilkanPelanggan(this.#allPelanggans);
    } else {
      alert('Gagal memuat data pelanggan dari server');
      this.#view.tampilkanPelanggan([]);
    }
  }

  async tambahPelanggan(pelanggan) {
    const { namaPelanggan, alamat, noTelp } = pelanggan;
    const response = await this.#model.storeNewPelanggan({ namaPelanggan, alamat, noTelp });

    if (response.ok) {
      alert(response.message || 'Pelanggan berhasil ditambahkan');
      await this.loadPelanggan();
    } else {
      alert(response.message || 'Gagal menambahkan pelanggan');
    }
  }

  async hapusPelanggan(id) {
    const response = await this.#model.deletePelangganById(id);
    if (response.ok) {
      alert(response.message || 'Pelanggan berhasil dihapus');
      await this.loadPelanggan();
    } else {
      alert(response.message || 'Gagal menghapus pelanggan');
    }
  }

  async updatePelanggan(pelanggan) {
    const response = await this.#model.updatePelanggan(pelanggan);
    if (response.ok) {
      alert(response.message || 'Pelanggan berhasil diperbarui');
      await this.loadPelanggan();
    } else {
      alert(response.message || 'Gagal memperbarui pelanggan');
    }
  }

  filterPelanggan(keyword) {
    if (!keyword) {
      this.#view.tampilkanPelanggan(this.#allPelanggans);
      return;
    }

    const filteredPelanggan = this.#allPelanggans.filter(
      (pelanggan) =>
        pelanggan.id.toLowerCase().includes(keyword) ||
        pelanggan.namaPelanggan.toLowerCase().includes(keyword),
    );
    this.#view.tampilkanPelanggan(filteredPelanggan);
  }

  isPelangganNameDuplicate(namaPelanggan) {
    return this.#allPelanggans.some(
      (pelanggan) => pelanggan.namaPelanggan.toLowerCase() === namaPelanggan.toLowerCase(),
    );
  }
}
