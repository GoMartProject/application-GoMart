import * as GoMartAPI from '../../data/api';
import masterPelangganPresenter from './masterPelanggan-presenter';

export default class masterPelangganPage {
  #presenter;
  #editMode = false;
  #editId = null;
  #editNamaPelanggan = null;

  async render() {
    return `
            <div class="containermasterpelanggan">
                <h2>Master Pelanggan</h2>

                <form id="pelangganForm" class="pelangganForm">
                    <div class="form-control">
                        <label for="idpelanggan">ID Pelanggan</label>
                        <div class="pelanggan-form_title-container">
                            <input type="text" id="idpelanggan" placeholder="ID akan otomatis terisi" disabled required />
                        </div>
                    </div>

                    <div class="form-control">
                        <label for="namaPelanggan">Nama Pelanggan</label>
                        <div class="pelanggan-form_title-container">
                            <input type="text" id="namaPelanggan" placeholder="Nama Pelanggan" required />
                        </div>
                    </div>

                    <div class="form-control">
                        <label for="alamat">Alamat</label>
                        <div class="pelanggan-form_title-container">
                            <input type="text" id="alamat" placeholder="Alamat Pelanggan" required />
                        </div>
                    </div>

                    <div class="form-control">
                        <label for="noTelp">Nomor Telepon</label>
                        <div class="pelanggan-form_title-container">
                            <input type="tel" id="noTelp" placeholder="08xxxxxxxxxx" required />
                        </div>
                    </div>

                    <div class="pelanggan-form-buttons">
                        <button type="submit" class="submit-pelanggan btn">Tambah Pelanggan</button>
                    </div>
                </form>

                <div class="pelanggan-search">
                    <input
                        type="text"
                        id="searchInputPelanggan"
                        placeholder="Cari berdasarkan ID atau Nama Pelanggan..."
                    />
                </div>

                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>No. Telepon</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="pelangganTableBody">
                        </tbody>
                    </table>
                </div>
            </div>
        `;
  }

  async afterRender() {
    this.#presenter = new masterPelangganPresenter({
      view: this,
      model: GoMartAPI,
    });

    this.#setupForm();
    this.#setupSearch();
    await this.#presenter.loadPelanggan();
  }

  resetFormToTambahMode() {
    const form = document.getElementById('pelangganForm');
    const buttonSubmit = form.querySelector('button[type="submit"]');
    const idInput = form.querySelector('#idpelanggan');
    const namaPelangganInput = form.querySelector('#namaPelanggan');

    this.#editMode = false;
    this.#editId = null;
    this.#editNamaPelanggan = null;
    form.reset();
    namaPelangganInput.disabled = false;
    buttonSubmit.textContent = 'Tambah Pelanggan';
    idInput.value = '';

    document.querySelectorAll('.btn-cancel-row-edit').forEach((btn) => {
      btn.style.display = 'none';
    });
    document.querySelectorAll('.btn-edit').forEach((btn) => {
      btn.style.display = 'inline-block';
    });
  }

  #setupForm() {
    const form = document.getElementById('pelangganForm');
    const buttonSubmit = form.querySelector('button[type="submit"]');
    const idInput = form.querySelector('#idpelanggan');
    const namaPelangganInput = form.querySelector('#namaPelanggan');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const namaPelanggan = namaPelangganInput.value;
      const alamat = form.querySelector('#alamat').value;
      const noTelp = form.querySelector('#noTelp').value;

      if (!this.#editMode && this.#presenter.isPelangganNameDuplicate(namaPelanggan)) {
        alert('Nama Pelanggan sudah ada.');
        return;
      }
      if (
        this.#editMode &&
        namaPelanggan.toLowerCase() !== this.#editNamaPelanggan.toLowerCase() &&
        this.#presenter.isPelangganNameDuplicate(namaPelanggan)
      ) {
        alert('Nama Pelanggan sudah ada pada pelanggan lain.');
        return;
      }

      const pelangganData = {
        ...(this.#editMode && { id: this.#editId }),
        namaPelanggan,
        alamat,
        noTelp,
      };

      if (this.#editMode) {
        await this.#presenter.updatePelanggan(pelangganData);
      } else {
        await this.#presenter.tambahPelanggan(pelangganData);
      }

      this.resetFormToTambahMode();
    });
  }

  #setupSearch() {
    const searchInput = document.getElementById('searchInputPelanggan');
    searchInput.addEventListener('input', (e) => {
      const keyword = e.target.value.toLowerCase();
      this.#presenter.filterPelanggan(keyword);
    });
  }

  tampilkanPelanggan(pelanggans) {
    const tbody = document.getElementById('pelangganTableBody');
    tbody.innerHTML = '';

    if (!pelanggans || pelanggans.length === 0) {
      tbody.innerHTML =
        '<tr><td colspan="5" style="text-align: center;">Tidak ada data pelanggan.</td></tr>';
      return;
    }

    pelanggans.forEach((pelanggan) => {
      const row = document.createElement('tr');

      row.innerHTML = `
                <td>${pelanggan.id}</td>
                <td>${pelanggan.namaPelanggan}</td>
                <td>${pelanggan.alamat}</td>
                <td>${pelanggan.noTelp}</td>
                <td class="actions">
                    <button class="btn-hapus" data-id="${pelanggan.id}">Hapus</button>
                    <button class="btn-edit" data-id="${pelanggan.id}">Edit</button>
                    <button class="btn-cancel-row-edit btn" data-id="${pelanggan.id}" style="display: none;">Batal</button>
                </td>
            `;

      tbody.appendChild(row);
    });

    document.querySelectorAll('.btn-hapus').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.id;
        const row = btn.closest('tr');
        const namaPelangganCell = row ? row.children[1].textContent : 'pelanggan ini';
        const confirmDelete = confirm(
          `Apakah Anda yakin ingin menghapus pelanggan "${namaPelangganCell}" (ID: ${id})?`,
        );
        if (confirmDelete) {
          await this.#presenter.hapusPelanggan(id);
        }
      });
    });

    document.querySelectorAll('.btn-edit').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.resetFormToTambahMode();

        const form = document.getElementById('pelangganForm');
        const buttonSubmit = form.querySelector('button[type="submit"]');
        const id = btn.dataset.id;
        const pelanggan = pelanggans.find((b) => b.id === id);

        if (pelanggan) {
          btn.style.display = 'none';

          const cancelRowButton = btn.parentNode.querySelector('.btn-cancel-row-edit');
          if (cancelRowButton) {
            cancelRowButton.style.display = 'inline-block';
          }

          form.querySelector('#idpelanggan').value = pelanggan.id;
          form.querySelector('#namaPelanggan').value = pelanggan.namaPelanggan;
          form.querySelector('#namaPelanggan').disabled = true;
          form.querySelector('#alamat').value = pelanggan.alamat;
          form.querySelector('#noTelp').value = pelanggan.noTelp;

          this.#editMode = true;
          this.#editId = pelanggan.id;
          this.#editNamaPelanggan = pelanggan.namaPelanggan;

          buttonSubmit.textContent = 'Simpan Perubahan';
        }
      });
    });

    document.querySelectorAll('.btn-cancel-row-edit').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.resetFormToTambahMode();
      });
    });
  }
}
