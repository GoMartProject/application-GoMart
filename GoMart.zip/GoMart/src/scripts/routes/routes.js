import { checkRouteAccess } from '../utils/auth';
import LoginPage from '../pages/auth/login/login-page';
import RegisterPage from '../pages/auth/register/register-page';
import HomePage from '../pages/home/home-page';
import masterBarang from '../pages/masterBarang/masterBarang-page';
import masterPelangganPage from '../pages/masterPelanggan/masterPelanggan-page';
import TransaksiPage from '../pages/transaksi/transaksi-page';
import LaporanPenjualanPage from '../pages/laporan/laporan-penjualan-page';

const routes = {
  '/': () => checkRouteAccess(new HomePage()),
  '/login': () => checkRouteAccess(new LoginPage()),
  '/register': () => checkRouteAccess(new RegisterPage()),
  '/masterBarang': () => checkRouteAccess(new masterBarang()),
  '/masterPelanggan': () => checkRouteAccess(new masterPelangganPage()),
  '/transaksiPenjualan': () => checkRouteAccess(new TransaksiPage()),
  '/laporan': () => checkRouteAccess(new LaporanPenjualanPage()),
};

export default routes;
